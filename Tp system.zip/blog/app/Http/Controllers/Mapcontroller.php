<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Mapcontroller extends Controller
{
    public function Map()
    {
    	
        return view('Map');
    }
}
