<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Pricecontroller extends Controller
{
     public function price()
    {
        return view('Price');
    }
}
