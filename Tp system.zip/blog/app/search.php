<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class search extends Model
{
    protected $table = 'home';
}


