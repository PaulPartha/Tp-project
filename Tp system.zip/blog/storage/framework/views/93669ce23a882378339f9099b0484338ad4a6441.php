




<html>
<head>
<title> Registration</title>
<style>

.registration form{
padding-top:5%;
color: ;
font-size:18;
}
body{

}

</style>
</head>
<center><body style="background-image:url('regis.jpg'); background-repeat: no-repeat; background-position: center; background-size:cover ;">
<div >
<h1 style="color:"><center></center></h1>
</div>

<pre>


</pre>

	<?php if(count ($errors) > 0): ?>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<p class="alert alert-danger" style="color:red"><?php echo e($error); ?></p>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>

<form method="post" action="/Registrationsave">
<?php echo e(csrf_field()); ?>

			First Name :    
				<input type="text" name="fname" placeholder="First Name" value="<?php echo e(old('fname')); ?>" value="<?php echo e(old('fname')); ?>" required>
			Last Name:
				<input type="text" name="lname" placeholder="Last Name" value="<?php echo e(old('lname')); ?>" required><br><br>
			Email Address:
				<input type="text" name="email" placeholder=" Email Address" value="<?php echo e(old('email')); ?>" required><br><br>
			Password:
			  <input type="password" name="password" placeholder="New password"  required><br><br>
			Confirm-password:
				<input type="password" name="password_confirmation" placeholder="Confirm-password" required><br><br>
			Phone Number:
				<input type="text" name="phn" placeholder="Phone Number" value="<?php echo e(old('phn')); ?>" required><br><br>
			Birthday:
				<input type="date" name="birthday" style="width:10%;height:5%" value="<?php echo e(old('birthday')); ?>" required><br><br> 

			<div style="color:">
				<input type="radio" name="gender" value="Female"> Female
				<input type="radio" name="gender" value="Male" >Male<br><br>
		</div>
		Address:<br>
		<textarea rows="4" cols="40" name="address" value="" required></textarea><br><br>
			

			<input type="submit" value="Submit" onclick="clickAlert()" style="background-color:green; width:10%;height:5% " >
			


</form>
<h3>Already A Member? <a href="Login">Login</a></h3>

</body>
</html>

