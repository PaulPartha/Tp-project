

<!DOCTYPE html>
<html>
<head>
	<title>Edit</title>
</head>
<body>

<center></br></br>
<h2  style="color:blue"> Edit Dates & Times </h2>
<form method="POST" action="homesave">
<?php echo e(csrf_field()); ?>


<level><h2  style="">Entry Date & Time</h2><level>
<input type="date" name="entrydate" style="width:10%;height:5%" >  <input type="time" name="entrytime" style="width:8%;height:5%" ></br>
<level><h2  style="">Exit Date & Time</h2><level>
<input type="date" name="exitdate"  style="width:10%;height:5%" >  <input type="time" name="exittime" style="width:8%;height:5%" ></br></br>
<input type="text" name="number" placeholder="Car Number" style="width:15%;height:5%;font-size:15px"></br></br>
<!-- Show message-->
	<script>
		  function clickAlert() {
			alert("Data has been inserted");
		   }
	</script>
<input type="submit" value="Submit" onclick="clickAlert()" style=" background-color :blue; color:white;height:15%;">
<!-- end message-->
</form>
</center>

</body>
</html>

