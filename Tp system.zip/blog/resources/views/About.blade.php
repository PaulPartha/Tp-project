<html>
<head><title>About Us</title>
<style>
*{
margin:0;
padding:0;
}
#main{
width:100%;
height:9%;
background-color:black;

}
#main ul{
list-style:none;
}
#main ul li{
width:320px;
float:left;
padding-top:20px;
text-align:center;
}
#main ul li:hover{
background-color:green;
height:63%;
}
#main ul li:hover ul{

display:block;}
#main ul li a{
text-decoration:none;
}
#main ul li h3{
color:white;
}
<!--end menu -->


.start{

}
.one{
width:100%;
height:40%;
text-align:center;
}
.one h2{
color:gray;
}
.two{
width:100%;
height:30%;
text-align:center;
}
.two h2{
color:gray;
}

.three{
width:100%;
height:40%;
text-align:center;
}
.three h2{
color:gray;

}

.four{
width:100%;
height:40%;
text-align:center;
}
.four h2{
color:gray;
}

.five{
width:100%;
height:40%;
text-align:center;
}
.five h2{
color:gray;
}
</style>
</head>
	
	<body>
		
	<div id="main">
<ul>
<li><a href="myhome"><h3>Home</h3></a></li>
<li><a   href="about"><h3>About</h3></a></li>
<li><a   href="price"><h3>Price</h3></a></li>
<li><a   href="contact"><h3>Contact </h3></a></li>
</ul>
</div>
	<div class="Start">
	<img src="about.png">
	
	<div class="one">
	<pre>
    <h1>  * Car Park Booking System</h1>
	<h2>    The built-in parking reservation
	system allows you to manage bookings,
    customer details, park space types 
	and extra services on your car 
	    parking website.</h2>
		</pre>
	</div>
    	
		
		<div class="two">
	<pre>
    <h1>    * Payment Process</h1>
	<h2>      You can pay card or cash.</h2>
		</pre>
	</div>
	
	<div class="three">
	<pre>
    <h1>    * Park Spaces & Extras</h1>
	<h2>   Add and manage different types
        of parking spaces and offer various 
	extra services such as car wash, 
	express lane, meet and greet, etc.
	Track availability from the admin page.</h2>
		</pre>
	</div>
	
	<div class="four">
	<pre>
    <h1>    * Manage Prices & Promos</h1>
	<h2>      Set standard parking fees 
	    (per hour, per day, etc.) for
	    particular periods. Launch hot 
	    offers and special discounts to
          promote sales and foster customer loyalty..</h2>
		</pre>
	</div>
	
	<div class="five">
	<pre>
    <h1>    * Email & SMS Notifications</h1>
	<h2>   Stay up to date with the latest
        car parking bookings and payments and 
		send your clients electronic confirmations.
	  You can customize your Emails and SMS messages.</h2>
		</pre>
	</div>
	</div>
</body>
</html>