<html>
<head><title>Price</title></head>

<style>
*{
margin:0;
padding:0;
}
.start{
width:100%;
height:9%;
background-color:black;
}

}
#main ul{
list-style:none;
background-color:;
text-align:right;

}
#main{display:block}
#main ul li{
background-color:black;
width:300px;
border:1px solid black;
height:50px;
line-height:50px;
list-style:center;
text-align:center;
float:left;
padding-left:20px;
}
#main ul li:hover{
background-color:green;
height:56px;
}
#main ul li:hover ul{

display:block;}
#main ul li h3{
color:white;
}

#main ul li a{
text-decoration:none;
}
.price table{
width:70%;
height:60%;
}
.price table tr td{
text-align:center;
font-size:20;
color:green;
}
.price table tr th{
text-align:center;
font-size:20;
color:green;
}
</style>

<body background="price.jpg">
<div class="start">
<div id="main">
<ul>
<li><a href="myhome"><h3>Home</h3></a></li>
<li><a   href="about"><h3>About</h3></a></li>
<li><a   href="price"><h3>Price</h3></a></li>
<li><a   href="contact"><h3>Contact </h3></a></li>
</ul>
</div>
</div>
<pre>





<h1><center>Transport Parking Price List</center></h1>
<center>
<div class="price">
<table border="1" cellpadding="10" cellspacing="10" style="background-color:white">

<tr>
<th >Name</th>
<th>Per Hour(BDT)</th>
<th>Per Day(BDT)</th>
<th>Monthly( BDT)</th>
</tr>

<tr>
<td>Truck</td>
<td>200</td>
<td>5000</td>
<td style="color:green">8000 </td>
</tr>

<tr>
<td>Bus</td>
<td>150</td>
<td>3000</td>
<td style="color:green">8000 </td>
</tr>

<tr>
<td>Car</td>
<td>100</td>
<td>2000</td>
<td style="color:green">8000</td>
</tr>

<tr>
<td>Bike</td>
<td>50</td>
<td>500</td>
<td style="color:green">8000 </td>
</tr>

<tr>
<td>Cycle</td>
<td>20</td>
<td>150</td>
<td style="color:green" >8000 </td>
</tr>



</table>
</div>
</center>
</pre>
</body>

<html>