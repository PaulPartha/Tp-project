<html>
<head>
<title>Our location</title>
<style>
	*{
	margin:0px;
	padding:0px;
	}
	.map {
	widows: auto;
	
	}
	
</style>
</head>

<body>
	<div class="map">
	  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3651.881275056915!2d90.3751022!3d23.7516128!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8ad9a69f36f%3A0xffd63d9e3af04553!2sDhanmondi+32+Bus+Stop!5e0!3m2!1sen!2sbd!4v1518535065439"
	   	width="100%" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>

</body>

</html>


